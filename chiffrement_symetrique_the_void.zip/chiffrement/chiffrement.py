import base64
import json
import csv
import os
import random


présentation = """
===========================
Yb    dP .d88b. 888 888b. 
 Yb  dP  8P  Y8  8  8   8 
  YbdP   8b  d8  8  8   8 
   YP    `Y88P' 888 888P' 
===========================
"""

class CryptographieAvancee:
    def __init__(self):
        # Initialisation des dossiers pour les fichiers
        self.tokens_dir = os.path.join(os.path.dirname(os.path.abspath(__file__)), "tokens")
        self.keys_dir = os.path.join(os.path.dirname(os.path.abspath(__file__)), "keys")
        os.makedirs(self.tokens_dir, exist_ok=True)
        os.makedirs(self.keys_dir, exist_ok=True)

        # Initialisation du chiffrement invisible
        self.alphabet = 'abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789'
        self.invisible_map = {
            'a': '⁰', 'b': 'ⁱ', 'c': '⁲', 'd': '⁳', 'e': '⁴', 'f': '⁵', 'g': '⁶', 'h': '⁷', 'i': '⁸',
            'j': '⁹', 'k': '₀', 'l': '₁', 'm': '₂', 'n': '₃', 'o': '₄', 'p': '₅', 'q': '₆', 'r': '₇',
            's': '₈', 't': '₉', 'u': 'ₑ', 'v': 'ₒ', 'w': 'ₓ', 'x': 'ₔ', 'y': 'ₕ', 'z': 'ₖ',
            'A': 'ₘ', 'B': 'ₙ', 'C': 'ₚ', 'D': 'ₛ', 'E': 'ₜ', 'F': 'ᵤ', 'G': 'ᵥ', 'H': 'ᵦ', 'I': 'ᵧ',
            'J': 'ᵨ', 'K': 'ᵩ', 'L': 'ᵪ', 'M': 'ᵫ', 'N': 'ᵬ', 'O': 'ᵭ', 'P': 'ᵮ', 'Q': 'ᵯ',
            'R': 'ᵰ', 'S': 'ᵱ', 'T': 'ᵲ', 'U': 'ᵳ', 'V': 'ᵴ', 'W': 'ᵵ', 'X': 'ᵶ', 'Y': 'ᵷ', 'Z': 'ᵸ',
            '0': 'ᵹ', '1': 'ᵺ', '2': 'ᵻ', '3': 'ᵼ', '4': 'ᵽ', '5': 'ᵾ', '6': 'ᵿ', '7': '⒀', '8': '⒁',
            '9': '⒂'
        }
        self.invisible_map_rev = {v: k for k, v in self.invisible_map.items()}
        
        # Initialisation de la segmentation
        self.unicode_map = {
            "1": "\u2000", "2": "\u2001", "3": "\u2002", "4": "\u2003", 
            "5": "\u2004", "6": "\u2005", "7": "\u2006", "8": "\u2007", 
            "9": "\u2008", "0": "\u2009", " ": "\u200A"
        }
        self.unicode_map_rev = {v: k for k, v in self.unicode_map.items()}
        
        # Chargement de la base de données
        self.db = self.load_db()
    
    # Méthodes du chiffrement invisible
    def _appliquer_decalage(self, char, decalage):
        """Applique un décalage alphabétique à un caractère."""
        if char not in self.alphabet:
            return char
        idx = self.alphabet.index(char)
        new_idx = (idx + decalage) % len(self.alphabet)
        return self.alphabet[new_idx]
    
    def encrypt_invisible(self, message):
        """Première phase de chiffrement: caractères invisibles."""
        key = random.randint(1, len(self.alphabet))
        ciphertext = []
        for i, char in enumerate(message):
            if char in self.alphabet:
                decalage = (key + i) % len(self.alphabet)
                ciphertext.append(self.invisible_map.get(self._appliquer_decalage(char, decalage), char))
            else:
                ciphertext.append(char)
        
        metadata = {"key": key}
        metadata_encoded = base64.urlsafe_b64encode(json.dumps(metadata).encode()).decode().rstrip("=")
        signature = ''.join([self.invisible_map.get(c, c) for c in metadata_encoded])
        return ''.join(ciphertext) + "::" + signature
    
    def decrypt_invisible(self, ciphertext):
        """Déchiffre la première phase (caractères invisibles)."""
        if not ciphertext:
            return ciphertext
        
        try:
            encrypted_part, signature_part = ciphertext.rsplit("::", 1)
            signature_visible = ''.join([self.invisible_map_rev.get(c, c) for c in signature_part])
            signature_visible = signature_visible + '=' * (4 - len(signature_visible) % 4)
            
            metadata_encoded = base64.b64decode(signature_visible.encode()).decode()
            metadata = json.loads(metadata_encoded)
            key = metadata.get("key", 1)
        except Exception:
            return "[ERREUR] Format du message chiffré invalide."

        texte_intermediaire = []
        for i, c in enumerate(encrypted_part):
            if c in self.invisible_map_rev:
                char_visible = self.invisible_map_rev.get(c)
                decalage = (key + i) % len(self.alphabet)
                texte_intermediaire.append(self._appliquer_decalage(char_visible, -decalage))
            else:
                texte_intermediaire.append(c)
        return ''.join(texte_intermediaire)
    
    # Méthodes de segmentation et tokenisation
    def load_db(self, db_filename="db_updated.csv"):
        """Charge la base de données depuis le fichier CSV."""
        db = {}
        script_dir = os.path.dirname(os.path.abspath(__file__))
        path = os.path.join(script_dir, db_filename)
        if not os.path.exists(path):
            raise FileNotFoundError(f"Le fichier '{db_filename}' est introuvable. Assurez-vous qu'il est présent dans le répertoire.")
        
        try:
            with open(path, newline='', encoding='utf-8') as f:
                reader = csv.DictReader(f)
                for row in reader:
                    dim = row.get("dimension", "").strip()
                    eid = row.get("element_id", "").strip()
                    if dim and eid:
                        db.setdefault(dim, []).append(eid)
        except Exception as e:
            raise ValueError(f"Erreur lors du chargement de '{db_filename}': {e}")
        
        if not db:
            raise ValueError(f"Le fichier '{db_filename}' est vide ou mal formaté.")
        
        return db
    
    def generate_segmentation(self, message, min_seg=2, max_seg=7):
        segments, lengths = [], []
        idx, total = 0, len(message)
        while idx < total:
            remaining = total - idx
            if remaining < min_seg:
                seg_len = remaining
            else:
                max_possible = min(max_seg, remaining)
                seg_len = remaining if min_seg > max_possible else random.randint(min_seg, max_possible)
            segments.append(message[idx: idx + seg_len])
            lengths.append(seg_len)
            idx += seg_len
        return segments, lengths
    
    def translate_to_unicode(self, message):
        return "|" + "".join(self.unicode_map.get(char, char) for char in message) + "|"
    
    def translate_from_unicode(self, unicode_str):
        if unicode_str.startswith("|") and unicode_str.endswith("|"):
            unicode_str = unicode_str[1:-1]
        return "".join(self.unicode_map_rev.get(c, c) for c in unicode_str)
    
    def encrypt_segmentation(self, message):
        if not message:
            return [], {}
        
        my_seed = random.randint(1000, 9999)
        random.seed(my_seed)
        segments, seg_lengths = self.generate_segmentation(message)
        token_chain, mapping = [], {}

        for i, seg in enumerate(segments):
            L = len(seg)
            dimension = f"{L}x{L}"
            candidates = self.db.get(dimension)
            token = random.choice(candidates) if candidates else "0000"
            token_chain.append(token)
            mapping[i] = seg

        all_ids = [eid for lst in self.db.values() for eid in lst]
        salt_token = random.choice(all_ids) if all_ids else "0000"
        salt_position = random.randint(0, len(token_chain))
        token_chain.insert(salt_position, salt_token)

        seed_info = {
            "seed": my_seed,
            "segmentation": seg_lengths,
            "salt_position": salt_position,
            "salt_token": salt_token,
            "mapping": {k: base64.b64encode(v.encode()).decode() for k, v in mapping.items()}
        }

        numeric_result = "".join(token_chain)
        unicode_result = self.translate_to_unicode(numeric_result)
        return unicode_result, seed_info
    
    def decrypt_segmentation(self, unicode_message, seed_info):
        numeric_chain = self.translate_from_unicode(unicode_message)
        salt_pos = seed_info.get("salt_position")
        token_chain = [numeric_chain[i:i+4] for i in range(0, len(numeric_chain), 4)]
        
        chain_without_salt = token_chain[:salt_pos] + token_chain[salt_pos+1:]
        mapping = {int(k): base64.b64decode(v).decode() for k, v in seed_info["mapping"].items()}
        segments = [mapping[i] for i in sorted(mapping.keys())]
        return "".join(segments)
    
    # Méthodes combinées
    def encrypt_full(self, message):
        """Chiffrement complet en deux phases."""
        # Phase 1: Chiffrement invisible
        invisible_cipher = self.encrypt_invisible(message)
        
        # Phase 2: Segmentation et tokenisation
        segmented_cipher, seed_info = self.encrypt_segmentation(invisible_cipher)
        
        return segmented_cipher, seed_info
    
    def decrypt_full(self, ciphertext, seed_info):
        """Déchiffrement complet en deux phases."""
        # Phase 2: Décryptage de la segmentation
        invisible_cipher = self.decrypt_segmentation(ciphertext, seed_info)
        
        # Phase 1: Décryptage des caractères invisibles
        original_message = self.decrypt_invisible(invisible_cipher)
        
        return original_message
    
    def save_encrypted(self, ciphertext, seed_info, base_filename="encrypted_output"):
        """Sauvegarde les données chiffrées dans deux fichiers distincts."""
        tokens_path = os.path.join(self.tokens_dir, f"{base_filename}.tokens")
        key_path = os.path.join(self.keys_dir, f"{base_filename}.key")
        
        # Sauvegarder le token
        with open(tokens_path, "w", encoding="utf-8") as f:
            f.write(ciphertext)
        
        # Sauvegarder la clé
        with open(key_path, "w", encoding="utf-8") as f:
            json.dump(seed_info, f, indent=2)
        
        print(f"Fichiers sauvegardés : {tokens_path} et {key_path}")
    
    def load_encrypted(self, base_filename="encrypted_output"):
        """Charge les données chiffrées depuis deux fichiers distincts."""
        tokens_path = os.path.join(self.tokens_dir, f"{base_filename}.tokens")
        key_path = os.path.join(self.keys_dir, f"{base_filename}.key")

        if not os.path.exists(tokens_path) or not os.path.exists(key_path):
            return None, None, None, None

        with open(tokens_path, "r", encoding="utf-8") as f:
            ciphertext = f.read().strip()
        
        with open(key_path, "r", encoding="utf-8") as f:
            seed_info = json.load(f)
        
        return ciphertext, seed_info, tokens_path, key_path
    
    def delete_files(self, paths):
        """Supprime les fichiers temporaires."""
        for path in paths:
            try:
                os.remove(path)
            except Exception as e:
                print(f"Erreur lors de la suppression du fichier {path} : {e}")


def main():
    crypto = CryptographieAvancee()
    print(présentation)

    while True:
        print("=== Bienvenu sur la cryptographie The VOID ===")
        print("+---------------------------+")
        print("| 1. Chiffrer un message    |")
        print("| 2. Déchiffrer un message  |")
        print("| 3. Quitter                |")
        print("+---------------------------+")
        choix = input("Choisissez une option (1-3): ").strip()
        
        if choix == '1':
            message = input("Entrez le message à chiffrer: ")
            ciphertext, seed_info = crypto.encrypt_full(message)
            print("\nMessage chiffré (phase 2):")
            print(ciphertext)
            
            base_filename = input("\nNom de base pour les fichiers de sortie (sans extension): ").strip()
            base_filename = base_filename or "encrypted_output"
            crypto.save_encrypted(ciphertext, seed_info, base_filename)
        
        elif choix == '2':
            base_filename = input("Nom de base des fichiers chiffrés (sans extension): ").strip()
            base_filename = base_filename or "encrypted_output"
            ciphertext, seed_info, token_path, key_path = crypto.load_encrypted(base_filename)
            
            if ciphertext is None or seed_info is None:
                print("\nFichiers introuvables ou incomplets. Vérifiez le nom.")
                continue
            
            try:
                message = crypto.decrypt_full(ciphertext, seed_info)
                print("\nMessage déchiffré:")
                print(message)
                
                # Suppression des fichiers après déchiffrement
                crypto.delete_files([token_path, key_path])
            except Exception as e:
                print(f"\nErreur lors du déchiffrement: {e}")
        
        elif choix == '3':
            print("Au revoir!")
            break
        
        else:
            print("Option invalide. Veuillez choisir entre 1 et 3.")


if __name__ == "__main__":
    main()