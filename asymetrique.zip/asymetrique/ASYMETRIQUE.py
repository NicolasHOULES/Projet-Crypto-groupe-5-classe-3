import random
import json
import os
import hashlib
import math

def curve(x, a, b, p):
    term1 = pow(x, 3, p)
    term2 = (a * pow(x, 2, p)) % p
    term3 = (b * x) % p
    hash_input = f"{x}:{a}:{b}".encode()
    hash_digest = hashlib.sha256(hash_input).hexdigest()
    hash_int = int(hash_digest[:8], 16)  
    term4 = hash_int % p
    sine_term = int((math.sin(x) + 1) * 1000) % p

    result = (term1 + term2 + term3 + term4 + sine_term) % p
    return result

# Clé privée = (a, b, p)
def generate_private_key():
    p = random.choice([104729, 130099, 172933])
    a = random.randint(2, p - 2)
    b = random.randint(2, p - 2)
    return a, b, p

# Clé publique = liste des points (x, y)
def generate_public_key(private_key):
    a, b, p = private_key
    charset = range(32, 127)
    public_points = [(x, curve(x, a, b, p)) for x in charset]
    return (p, public_points)

# Chiffrement avec plusieurs couches
def encrypt_asymmetric_complex(message, public_key):
    p, points = public_key
    point_dict = dict(points)
    cipher = []
    for c in message:
        x = ord(c)
        y = point_dict.get(x)
        if y is None:
            raise ValueError(f"Caractère non supporté : {c}")
        n = random.randint(1, 10)
        y_complex = (y * n + n**2) % p
        cipher.append((x, y_complex, n))
    return cipher

# Déchiffrement complexe
def decrypt_asymmetric_complex(ciphertext, private_key):
    a, b, p = private_key
    decrypted = ''
    for x, y_complex, n in ciphertext:
        expected_y = curve(x, a, b, p)
        recalculated = (expected_y * n + n**2) % p
        if y_complex == recalculated:
            decrypted += chr(x)
        else:
            decrypted += '?'
    return decrypted

def save_keys(public_key, private_key, key_name):
    os.makedirs("cles", exist_ok=True)
    with open(f"cles/public_{key_name}.json", "w") as f:
        json.dump({"p": public_key[0], "points": public_key[1]}, f)
    with open(f"cles/private_{key_name}.json", "w") as f:
        json.dump({"a": private_key[0], "b": private_key[1], "p": private_key[2]}, f)

def load_key(filename):
    with open(filename, "r") as f:
        return json.load(f)

def main():
    print("===== Cryptographie Asymétrique Curvax 🔐 =====")

    while True:
        print("\nMenu :")
        print("1. Générer une paire de clés")
        print("2. Chiffrer un message (complexe)")
        print("3. Déchiffrer un message (complexe)")
        print("4. Quitter")
        choice = input("Choix (1/2/3/4) : ").strip()

        if choice == "1":
            name = input("🔑 Nom de la paire de clés : ")
            private_key = generate_private_key()
            public_key = generate_public_key(private_key)
            save_keys(public_key, private_key, name)
            print(f"✅ Clés '{name}' générées et sauvegardées dans le dossier 'cles/'.")

        elif choice == "2":
            name = input("📂 Nom de la clé publique à utiliser : ")
            try:
                pub = load_key(f"cles/public_{name}.json")
                public_key = (pub["p"], [tuple(pt) for pt in pub["points"]])
                message = input("📝 Message à chiffrer : ")
                cipher = encrypt_asymmetric_complex(message, public_key)
                print("🔐 Message chiffré (complexe) :")
                print(cipher)
            except Exception as e:
                print("❌ Erreur :", e)

        elif choice == "3":
            name = input("📂 Nom de la clé privée à utiliser : ")
            try:
                priv = load_key(f"cles/private_{name}.json")
                private_key = (priv["a"], priv["b"], priv["p"])
                encrypted_input = input("🔒 Entrez le message chiffré complexe (ex: [(88, 45, 3), (77, 12, 5)]) :\n")
                encrypted = eval(encrypted_input.strip())
                decrypted = decrypt_asymmetric_complex(encrypted, private_key)
                print("✅ Message déchiffré :", decrypted)
            except Exception as e:
                print("❌ Erreur :", e)

        elif choice == "4":
            print("👋 Au revoir")
            break

        else:
            print("❌ Choix invalide.")

if __name__ == "__main__":
    main()
