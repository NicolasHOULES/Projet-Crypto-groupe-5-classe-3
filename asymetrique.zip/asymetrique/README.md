🧠 Curvax – Guide d'utilisation
Curvax est un outil simple de chiffrement asymétrique basé sur une fonction mathématique personnalisée. Ce guide présente uniquement les étapes d’installation et d’utilisation, sans détailler les mécanismes mathématiques.

📋 Table des matières

Prérequis

Installation

Structure du projet

Utilisation (CLI)

Exemple d'exécution

Organisation des fichiers générés

Licence

🔧 Prérequis
Python 3.7 ou supérieur

Modules standards : os, json, random

🚀 Installation
Cloner le dépôt :

bash
Copier
Modifier
git clone https://github.com/votre-utilisateur/curvax.git
cd curvax
(Optionnel) Créer un environnement virtuel :

bash
Copier
Modifier
python -m venv venv
source venv/bin/activate  # Sur Windows : venv\Scripts\activate
🗂 Structure du projet
bash
Copier
Modifier
curvax/
├── main.py               # Script principal CLI
└── cles/                 # Dossier contenant les clés .json
💻 Utilisation (CLI)
Lancer le programme :

bash
Copier
Modifier
python main.py
Menu principal :

markdown
Copier
Modifier
===== Cryptographie Asymétrique Curvax 🔐 =====

1. Générer une paire de clés
2. Chiffrer un message
3. Déchiffrer un message
4. Quitter
🛡 Fonctions disponibles
Générer une paire de clés
Saisir un nom pour identifier les clés.
→ Deux fichiers sont créés dans cles/ :

public_<nom>.json

private_<nom>.json

Chiffrer un message

Saisir le nom de la clé publique

Entrer le message à chiffrer
→ Affiche une liste de couples (x, y) représentant le message chiffré.

Déchiffrer un message

Saisir le nom de la clé privée

Coller la liste chiffrée (format : [(88, 45), (77, 12)])
→ Affiche le message en clair.

Quitter

Ferme le programme.

🖥 Exemple d'exécution
bash
Copier
Modifier
$ python main.py
Choix : 1
Nom de la paire de clés : secret2025
✅ Clés 'secret2025' générées.

$ python main.py
Choix : 2
Nom de la clé publique à utiliser : secret2025
Message à chiffrer : Hello!
🔐 Message chiffré : [(72, 16347), (101, 32767), ...]

$ python main.py
Choix : 3
Nom de la clé privée à utiliser : secret2025
Entrez le message chiffré : [(72, 16347), (101, 32767), ...]
✅ Message déchiffré : Hello!
📂 Organisation des fichiers
bash
Copier
Modifier
cles/
├── public_<nom>.json      # Clé publique
└── private_<nom>.json     # Clé privée